"""
Utility functions for the research crew application.
""" 