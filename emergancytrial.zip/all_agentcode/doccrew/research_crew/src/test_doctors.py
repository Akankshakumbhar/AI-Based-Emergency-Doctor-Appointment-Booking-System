#!/usr/bin/env python3

from research_crew.tools.custom_tool import filter_doctors, FAKE_DOCTORS, NEARBY_LOCATIONS

print(f"Generated {len(FAKE_DOCTORS)} doctors")

# Test filtering
result = filter_doctors('Cardiologist', 'Pune', 'Urgent', 'Star Health', 'low')
print(f"Found {len(result)} cardiologists in Pune (urgent) with Star Health insurance")

if result:
    print("Sample doctor:")
    doc = result[0]
    print(f"  Name: {doc['name']}")
    print(f"  Specialty: {doc['specialty']}")
    print(f"  Location: {doc['location']}")
    print(f"  Hospital: {doc['hospital']}")
    print(f"  Cost: ₹{doc['cost']}")
    print(f"  Insurance: {doc['insurance']}")
    print(f"  Available slots: {len(doc['available_slots'])}")

# Test nearby locations
print(f"\nNearby locations for Pune: {NEARBY_LOCATIONS['Pune']}")

# Test without insurance filter
result2 = filter_doctors('Cardiologist', 'Pune', 'Urgent', None, 'low')
print(f"Found {len(result2)} cardiologists in Pune (urgent) without insurance filter")

print("\n✅ Doctor filtering system is working correctly!") 