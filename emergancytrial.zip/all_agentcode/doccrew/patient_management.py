import json
import os
from datetime import datetime

class PatientManager:
    def __init__(self):
        self.patients_file = 'patients_database.json'
        self.appointments_file = 'appointments.json'
        self._initialize_files()

    def _initialize_files(self):
        """Initialize the database files if they don't exist"""
        if not os.path.exists(self.patients_file):
            with open(self.patients_file, 'w') as f:
                json.dump({'patients': {}}, f, indent=2)
        
        if not os.path.exists(self.appointments_file):
            with open(self.appointments_file, 'w') as f:
                json.dump({'appointments': []}, f, indent=2)

    def add_patient(self, patient_info):
        """Add or update patient information"""
        try:
            with open(self.patients_file, 'r') as f:
                database = json.load(f)
            
            patient_id = patient_info.get('patient_id', str(datetime.now().strftime('%Y%m%d%H%M%S')))
            
            # If patient exists, update their history
            if patient_id in database['patients']:
                current_data = database['patients'][patient_id]
                # Keep history of changes
                if 'history' not in current_data:
                    current_data['history'] = []
                current_data['history'].append({
                    'previous_data': {k:v for k,v in current_data.items() if k != 'history'},
                    'changed_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                })
                # Update with new data
                for key, value in patient_info.items():
                    current_data[key] = value
            else:
                # New patient
                patient_info['patient_id'] = patient_id
                patient_info['registered_at'] = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
                database['patients'][patient_id] = patient_info

            with open(self.patients_file, 'w') as f:
                json.dump(database, f, indent=2)
            
            return patient_id

        except Exception as e:
            print(f"Error saving patient data: {str(e)}")
            return None

    def get_patient(self, patient_id=None, name=None):
        """Retrieve patient information by ID or name"""
        try:
            with open(self.patients_file, 'r') as f:
                database = json.load(f)

            if patient_id:
                return database['patients'].get(patient_id)
            
            if name:
                # Search by name
                for patient in database['patients'].values():
                    if patient.get('name') == name:
                        return patient
            return None

        except Exception as e:
            print(f"Error retrieving patient data: {str(e)}")
            return None

    def get_patient_history(self, patient_id):
        """Get the history of changes for a patient"""
        patient = self.get_patient(patient_id)
        if patient and 'history' in patient:
            return patient['history']
        return []

    def get_patient_appointments(self, patient_id):
        """Get all appointments for a patient"""
        try:
            with open(self.appointments_file, 'r') as f:
                appointments = json.load(f)
            
            patient_appointments = []
            for appointment in appointments['appointments']:
                if appointment['patient'].get('patient_id') == patient_id:
                    patient_appointments.append(appointment)
            
            return patient_appointments

        except Exception as e:
            print(f"Error retrieving appointments: {str(e)}")
            return []

    def display_patient_info(self, patient_id):
        """Display complete patient information including history and appointments"""
        patient = self.get_patient(patient_id)
        if not patient:
            print(f"No patient found with ID: {patient_id}")
            return

        print("\n=== 👤 Patient Information ===")
        print(f"ID: {patient_id}")
        print(f"Name: {patient.get('name', 'N/A')}")
        print(f"Age: {patient.get('age', 'N/A')}")
        print(f"Contact: {patient.get('contact', 'N/A')}")
        print(f"Registered: {patient.get('registered_at', 'N/A')}")

        # Display history
        history = self.get_patient_history(patient_id)
        if history:
            print("\n=== 📋 Patient History ===")
            for entry in history:
                print(f"\nChanged at: {entry['changed_at']}")
                print("Previous data:")
                for key, value in entry['previous_data'].items():
                    if key not in ['history', 'patient_id']:
                        print(f"  {key}: {value}")

        # Display appointments
        appointments = self.get_patient_appointments(patient_id)
        if appointments:
            print("\n=== 📅 Appointments ===")
            for appointment in appointments:
                print(f"\nAppointment ID: {appointment['appointment_id']}")
                print(f"Doctor: Dr. {appointment['doctor']['name']}")
                print(f"Date & Time: {appointment['appointment_time']}")
                print(f"Status: {appointment['status']}")
                print(f"Location: {appointment['doctor']['clinic']}") 