document.addEventListener("DOMContentLoaded", () => {
    const chatBox = document.getElementById("chat-box");
    const userInput = document.getElementById("user-input");
    const sendButton = document.getElementById("send-button");
    
    const conversationId = "conv_" + Date.now();
    const ws = new WebSocket(`ws://localhost:8080/ws/${conversationId}`);

    function addMessage(message, sender) {
        const messageElement = document.createElement("div");
        messageElement.classList.add("message", `${sender}-message`);
        messageElement.innerHTML = message;
        chatBox.appendChild(messageElement);
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    ws.onopen = () => {
        addMessage("Connecting to the AI Healthcare Assistant...", "bot");
    };

    ws.onmessage = (event) => {
        console.log("Received message:", event.data);
        const response = JSON.parse(event.data);

        if (response.type === "question") {
            addMessage(response.data, "bot");
            userInput.disabled = false;
            sendButton.disabled = false;
            userInput.focus();
        } else if (response.type === "assessment") {
            console.log("Assessment data received:", response.data);
            const assessment = response.data;
            let assessmentHtml = `<div style="background-color: #f0f8ff; border: 2px solid #007bff; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #007bff; margin-top: 0;">🏥 Symptom Assessment</h3>
                <p><strong>Severity:</strong> ${assessment.severity || 'N/A'}</p>
                <p><strong>Urgency:</strong> ${assessment.urgency || 'N/A'}</p>
                <p><strong>Reasoning:</strong> ${assessment.reasoning || 'N/A'}</p>
                <p><strong>Recommendation:</strong> ${assessment.recommendations || 'N/A'}</p>
            </div>`;
            addMessage(assessmentHtml, "bot");
        } else if (response.type === "emergency") {
            console.log("🚨 Emergency response received:", response.data);
            displayEmergencyResponse(response.data);
        } else if (response.type === "emergency_notification") {
            console.log("🚨 Emergency notification received:", response.data);
            displayEmergencyNotification(response.data);
        } else if (response.type === "ai_virtual_doctor_ready") {
            console.log("🤖 AI Virtual Doctor ready:", response.data);
            displayAIVirtualDoctorReady(response.data);
        } else if (response.type === "ai_virtual_doctor") {
            console.log("🤖 AI Virtual Doctor response received:", response.data);
            displayAIVirtualDoctor(response.data);
        } else if (response.type === "ai_doctor_speech") {
            console.log("🗣️ AI Doctor speech received:", response.data);
            displayAIDoctorSpeech(response.data);
        } else if (response.type === "emergency_workflow_continue") {
            addMessage("🚨 " + response.data, "bot");
        } else if (response.type === "no_emergency") {
            addMessage("✅ " + response.data, "bot");
        } else if (response.type === "monitoring_started") {
            console.log("🔍 Monitoring started:", response.data);
            const monitoringData = response.data;
            let monitoringHtml = `<div style="background-color: #e8f5e8; border: 2px solid #4caf50; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #2e7d32; margin-top: 0;">🔍 Real-Time Monitoring Started</h3>
                <p><strong>Session ID:</strong> ${monitoringData.session_id || 'N/A'}</p>
                <p><strong>Status:</strong> ✅ Active</p>
                <p><strong>Monitoring Interval:</strong> ${monitoringData.monitoring_interval || '30 seconds'}</p>
                <p><strong>Vital Signs Tracking:</strong> ${monitoringData.vital_signs_tracking ? '✅ Enabled' : '❌ Disabled'}</p>
                <p style="font-size: 12px; color: #666; margin-top: 8px;">
                    <em>Emergency session is now being monitored in real-time. Updates will appear automatically.</em>
                </p>
            </div>`;
            addMessage(monitoringHtml, "bot");
        } else if (response.type === "monitoring_update") {
            console.log("🔍 Monitoring update:", response.data);
            const updateData = response.data;
            let updateHtml = `<div style="background-color: #f0f8ff; border: 1px solid #007bff; border-radius: 8px; padding: 10px; margin: 5px 0; font-size: 12px;">
                <strong>🔍 Update #${updateData.update_number}</strong> | 
                <span style="color: #007bff;">${updateData.status}</span> | 
                <span style="color: #666;">${new Date(updateData.timestamp).toLocaleTimeString()}</span>
                <br><small>${updateData.message}</small>
            </div>`;
            addMessage(updateHtml, "bot");
        } else if (response.type === "monitoring_completed") {
            console.log("🔍 Monitoring completed:", response.data);
            const completionData = response.data;
            let completionHtml = `<div style="background-color: #fff3cd; border: 2px solid #ffc107; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #856404; margin-top: 0;">✅ Monitoring Session Completed</h3>
                <p><strong>Session ID:</strong> ${completionData.session_id || 'N/A'}</p>
                <p><strong>Total Updates:</strong> ${completionData.total_updates || 'N/A'}</p>
                <p><strong>Status:</strong> ${completionData.status || 'Completed'}</p>
                <p style="font-size: 12px; color: #666; margin-top: 8px;">
                    <em>Emergency monitoring session has completed. Video call remains available if needed.</em>
                </p>
            </div>`;
            addMessage(completionHtml, "bot");
        } else if (response.type === "recommendations") {
            console.log("Recommendations data received:", response.data);
            
            // Check if it's raw text instead of JSON
            if (typeof response.data === 'string' && !response.data.trim().startsWith('{')) {
                console.log("⚠️ Agent returned text instead of JSON, trying to extract doctor info...");
                // Try to extract doctor information from text
                displayTextRecommendations(response.data);
            } else {
                displayRecommendations(response.data);
            }
            // Do NOT enable input here; only enable after slot is clicked
        } else if (response.type === "appointment_confirmed") {
            displayAppointmentConfirmation(response.data);
            userInput.disabled = true;
            sendButton.disabled = true;
        } else if (response.type === "reminder_scheduled") {
            console.log("Reminder scheduling result received:", response.data);
            const reminderData = response.data;
            let reminderHtml = `<div style="background-color: #fff3cd; border: 2px solid #ffc107; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #856404; margin-top: 0;">🔔 Reminder Scheduled</h3>
                <p><strong>Status:</strong> ${reminderData.status || 'Scheduled'}</p>
                <p><strong>Reminder Time:</strong> ${reminderData.reminder_time || 'N/A'}</p>
                <p><strong>Appointment Time:</strong> ${reminderData.appointment_time || 'N/A'}</p>
                <p><strong>Message Preview:</strong> ${reminderData.message_preview || 'N/A'}</p>
            </div>`;
            addMessage(reminderHtml, "bot");
        } else if (response.type === "immediate_reminder") {
            console.log("Immediate reminder result received:", response.data);
            const reminderData = response.data;
            let reminderHtml = `<div style="background-color: #d4edda; border: 2px solid #28a745; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #155724; margin-top: 0;">📱 Immediate Reminder Sent</h3>
                <p><strong>Status:</strong> ${reminderData.status || 'Sent'}</p>
                <p><strong>Message:</strong> ${reminderData.message || 'N/A'}</p>
            </div>`;
            addMessage(reminderHtml, "bot");
        } else if (response.type === "confirmation") {
            addMessage(response.data, "bot");
            userInput.disabled = true;
            sendButton.disabled = true;
        } else if (response.type === "error") {
            addMessage(`An error occurred: ${response.data}`, "bot");
        } else if (response.type === "initial_workflow_complete") {
            console.log("Initial workflow completed:", response.data);
            addMessage("✅ " + response.data, "bot");
            addMessage("💡 Click on any available slot above to book your appointment!", "bot");
            // Re-enable input for any additional questions
            userInput.disabled = false;
            sendButton.disabled = false;
        } else if (response.type === "final_result") {
            // Handle final result if needed
            console.log("Final result received:", response.data);
            addMessage("🎉 Complete workflow finished! Your appointment is booked and reminders are scheduled.", "bot");
        } else {
            console.error("Unknown response type:", response.type, response);
        }
    };

    function sendMessage() {
        const message = userInput.value;
        if (message.trim() !== "") {
            addMessage(message, "user");
            userInput.value = "";
            userInput.disabled = true;
            sendButton.disabled = true;

            // Agent-based booking - no need for manual booking confirmation
            // The agent will handle all booking logic through the conversation

            fetch(`/respond/${conversationId}`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ message: message }),
            });
        }
    }

    sendButton.addEventListener("click", sendMessage);
    userInput.addEventListener("keypress", (e) => {
        if (e.key === "Enter") {
            sendMessage();
        }
    });
    
    function displayRecommendations(recommendationsText) {
        // Always show the raw data for debugging
        addMessage("<pre>" + JSON.stringify(recommendationsText, null, 2) + "</pre>", "bot");
        try {
            console.log("🔍 DEBUG: Raw recommendations received:", recommendationsText);
            console.log("🔍 DEBUG: Recommendations type:", typeof recommendationsText);
            
            // Handle different data types and parsing scenarios
            let recommendations;
            if (typeof recommendationsText === 'string') {
                try {
                    // Try direct JSON parsing first
                    recommendations = JSON.parse(recommendationsText);
                    console.log("🔍 DEBUG: Successfully parsed JSON directly");
                } catch (parseError) {
                    console.error("🔍 DEBUG: JSON parse error:", parseError);
                    // Try to extract JSON from text using regex
                    const jsonMatch = recommendationsText.match(/\{[\s\S]*\}/);
                    if (jsonMatch) {
                        try {
                            recommendations = JSON.parse(jsonMatch[0]);
                            console.log("🔍 DEBUG: Successfully extracted and parsed JSON from text");
                        } catch (extractError) {
                            console.error("🔍 DEBUG: Failed to parse extracted JSON:", extractError);
                            throw new Error("No valid JSON found in recommendations");
                        }
                    } else {
                        console.error("🔍 DEBUG: No JSON pattern found in text");
                        throw new Error("No valid JSON found in recommendations");
                    }
                }
            } else {
                recommendations = recommendationsText;
                console.log("🔍 DEBUG: Using recommendations as object directly");
            }
            
            console.log("🔍 DEBUG: Final parsed recommendations:", recommendations);
            
            // Check for error in recommendations
            if (recommendations.error) {
                console.error("🔍 DEBUG: Recommendations contain error:", recommendations.error);
                addMessage(`❌ Error: ${recommendations.error}`, "bot");
                if (recommendations.message) {
                    addMessage(recommendations.message, "bot");
                }
                return;
            }
            
            // Display the main message
            if (recommendations.message) {
                addMessage(recommendations.message, "bot");
            }
            
            // Display insurance status (only if no insurance match)
            if (recommendations.patient_insurance && !recommendations.insurance_matched) {
                addMessage(`💡 Note: While none of these doctors accept ${recommendations.patient_insurance} insurance, they are available with other insurance providers.`, "bot");
            }
            
            // Display each doctor in chat format
            if (recommendations.recommended_doctors && recommendations.recommended_doctors.length > 0) {
                console.log(`🔍 DEBUG: Found ${recommendations.recommended_doctors.length} doctors to display`);
                
                recommendations.recommended_doctors.forEach((doctor, index) => {
                    console.log(`🔍 DEBUG: Displaying doctor ${index + 1}:`, doctor);
                    
                    let doctorInfo = `<div style="background-color: #f9f9f9; border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin: 10px 0;">
                        <strong>${index + 1}. ${doctor.name || 'Unknown Doctor'}</strong><br>
                        🏥 <strong>Specialty:</strong> ${doctor.specialty || 'Not specified'}<br>
                        🏥 <strong>Hospital:</strong> ${doctor.hospital || 'Not specified'}<br>
                        📍 <strong>Location:</strong> ${doctor.location || 'Not specified'}<br>
                        💰 <strong>Consultation Fee:</strong> ₹${doctor.cost || 'Not specified'}<br>`;
                    
                    // Add insurance information
                    if (doctor.insurance && doctor.insurance.length > 0) {
                        const insuranceStatus = doctor.insurance_accepted ? 
                            `✅ <span style="color: green;">Insurance Accepted</span>` : 
                            `⚠️ <span style="color: orange;">Different Insurance</span>`;
                        doctorInfo += `🏥 <strong>Insurance:</strong> ${doctor.insurance.join(', ')} ${insuranceStatus}<br>`;
                    }
                    
                    // Add available slots
                    if (doctor.available_slots && doctor.available_slots.length > 0) {
                        doctorInfo += `📅 <strong>Available Slots:</strong><br>`;
                        doctor.available_slots.forEach(slot => {
                            doctorInfo += `<button class="slot-button" 
                                data-doctor-name="${doctor.name || 'Unknown'}" 
                                data-doctor-specialty="${doctor.specialty || 'Unknown'}"
                                data-doctor-hospital="${doctor.hospital || 'Unknown'}"
                                data-slot-datetime="${slot.datetime || ''}"
                                data-slot-formatted="${slot.formatted_date || ''}">
                                📅 ${slot.formatted_date || slot.datetime || 'Unknown time'}
                            </button>`;
                        });
                    } else {
                        doctorInfo += `📅 <strong>Available Slots:</strong> No slots available<br>`;
                    }
                    
                    doctorInfo += `</div>`;
                    addMessage(doctorInfo, "bot");
                });
            } else {
                console.log("🔍 DEBUG: No doctors found in recommendations");
                addMessage("No doctors found matching your criteria. Please try different preferences.", "bot");
            }
        } catch (e) {
            console.error("❌ Error parsing recommendations:", e);
            console.error("❌ Raw recommendations data:", recommendationsText);
            addMessage("I couldn't read the doctor recommendations format. Please try again.", "bot");
            addMessage("If this problem persists, please contact support.", "bot");
        }
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    function displayTextRecommendations(textData) {
        try {
            console.log("🔍 Processing text-based recommendations:", textData);
            
            // Extract doctor information from text using regex patterns
            const doctorPattern = /Dr\.\s+([^(]+)\s*\(([^)]+)\)/g;
            const slotPattern = /(\d{4}-\d{2}-\d{2}\s+\d{1,2}:\d{2}\s+[AP]M)/g;
            
            let doctors = [];
            let match;
            
            // Extract doctors and their hospitals
            while ((match = doctorPattern.exec(textData)) !== null) {
                const doctorName = match[1].trim();
                const hospital = match[2].trim();
                
                // Extract slots for this doctor
                const slots = [];
                const slotMatch = textData.match(slotPattern);
                if (slotMatch) {
                    slotMatch.forEach(slot => {
                        slots.push({
                            datetime: slot,
                            formatted_date: slot
                        });
                    });
                }
                
                doctors.push({
                    name: `Dr. ${doctorName}`,
                    hospital: hospital,
                    specialty: "Gastroenterologist", // Default based on context
                    location: "Pune", // Default based on context
                    cost: 1600, // Default cost
                    insurance: ["Star Health", "ICICI Lombard", "HDFC Ergo"], // Default insurance
                    insurance_accepted: true,
                    available_slots: slots
                });
            }
            
            if (doctors.length > 0) {
                console.log(`🔍 Extracted ${doctors.length} doctors from text`);
                
                // Display each doctor in formatted way
                doctors.forEach((doctor, index) => {
                    let doctorInfo = `<div style="background-color: #f9f9f9; border: 1px solid #ddd; border-radius: 8px; padding: 15px; margin: 10px 0;">
                        <strong>${index + 1}. ${doctor.name}</strong><br>
                        🏥 <strong>Specialty:</strong> ${doctor.specialty}<br>
                        🏥 <strong>Hospital:</strong> ${doctor.hospital}<br>
                        📍 <strong>Location:</strong> ${doctor.location}<br>
                        💰 <strong>Consultation Fee:</strong> ₹${doctor.cost}<br>
                        🏥 <strong>Insurance:</strong> ${doctor.insurance.join(', ')} ✅ <span style="color: green;">Insurance Accepted</span><br>`;
                    
                    // Add available slots
                    if (doctor.available_slots && doctor.available_slots.length > 0) {
                        doctorInfo += `📅 <strong>Available Slots:</strong><br>`;
                        doctor.available_slots.forEach(slot => {
                            doctorInfo += `<button class="slot-button" 
                                data-doctor-name="${doctor.name}" 
                                data-doctor-specialty="${doctor.specialty}"
                                data-doctor-hospital="${doctor.hospital}"
                                data-slot-datetime="${slot.datetime}"
                                data-slot-formatted="${slot.formatted_date}">
                                📅 ${slot.formatted_date}
                            </button>`;
                        });
                    } else {
                        doctorInfo += `📅 <strong>Available Slots:</strong> No slots available<br>`;
                    }
                    
                    doctorInfo += `</div>`;
                    addMessage(doctorInfo, "bot");
                });
                
                // Add booking instruction
                addMessage("💡 Click on any available slot to book your appointment!", "bot");
                
            } else {
                console.log("🔍 No doctors extracted from text");
                addMessage("I found some doctor recommendations, but couldn't parse them properly. Please try again.", "bot");
            }
            
        } catch (e) {
            console.error("❌ Error processing text recommendations:", e);
            addMessage("I couldn't process the doctor recommendations properly. Please try again.", "bot");
        }
        chatBox.scrollTop = chatBox.scrollHeight;
    }
    
    // Add click listener for booking appointments - Direct API approach
    chatBox.addEventListener('click', (event) => {
        if (event.target && event.target.matches('button.slot-button')) {
            const button = event.target;
            document.querySelectorAll('.slot-button').forEach(btn => btn.disabled = true);

            // Add user message
            const bookingMessage = `I want to book an appointment with ${button.dataset.doctorName} for ${button.dataset.slotFormatted}`;
            addMessage(bookingMessage, "user");
            
            // Show booking in progress
            addMessage("🔄 Processing your booking request...", "bot");
            
            // Get patient info from the conversation state (we'll need to store this)
            // For now, we'll use default values and ask user if needed
            const bookingRequest = {
                doctor_name: button.dataset.doctorName,
                doctor_specialty: button.dataset.doctorSpecialty,
                doctor_hospital: button.dataset.doctorHospital,
                appointment_date: button.dataset.slotDatetime,
                conversation_id: conversationId // Pass conversation ID to get patient info
            };

            // Send booking request to the API
            fetch('/book-appointment', {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify(bookingRequest),
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === "success") {
                    displayAppointmentConfirmation(data.appointment);
                    addMessage("🎉 Your appointment has been successfully booked! You will receive a reminder 30 minutes before your appointment.", "bot");
                } else {
                    addMessage(`❌ Booking failed: ${data.message}`, "bot");
                    // Re-enable slot buttons
                    document.querySelectorAll('.slot-button').forEach(btn => btn.disabled = false);
                }
            })
            .catch(error => {
                console.error("Booking error:", error);
                addMessage("❌ An error occurred while booking your appointment. Please try again.", "bot");
                // Re-enable slot buttons
                document.querySelectorAll('.slot-button').forEach(btn => btn.disabled = false);
            });
        }
    });

    function displayAppointmentConfirmation(appointmentData) {
        try {
            const appointment = typeof appointmentData === 'string' ? JSON.parse(appointmentData) : appointmentData;
            
            let confirmationHtml = `<div style="background-color: #e8f5e8; border: 2px solid #4CAF50; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #2E7D32; margin-top: 0;">🎉 Appointment Confirmed!</h3>
                <p><strong>Appointment ID:</strong> ${appointment.appointment_id || 'N/A'}</p>`;
            
            // Only show patient name if it exists and is not a placeholder
            if (appointment.patient_name && 
                appointment.patient_name.trim() && 
                appointment.patient_name !== 'Unknown Patient' && 
                appointment.patient_name !== 'Patient') {
                confirmationHtml += `<p><strong>Patient:</strong> ${appointment.patient_name}</p>`;
            }
            
            confirmationHtml += `<p><strong>Doctor:</strong> ${appointment.doctor_name || 'N/A'} (${appointment.doctor_specialty || 'N/A'})</p>
                <p><strong>Date & Time:</strong> ${appointment.appointment_date || 'N/A'}</p>
                <p><strong>Hospital:</strong> ${appointment.hospital || 'N/A'}</p>
                <p><strong>Location:</strong> ${appointment.location || 'N/A'}</p>
                <p><strong>Cost:</strong> ₹${appointment.cost || 'N/A'}</p>`;
            
            // Only show contact if it exists and is not a placeholder
            if (appointment.patient_contact && 
                appointment.patient_contact.trim() && 
                appointment.patient_contact !== 'Not provided') {
                confirmationHtml += `<p><strong>Contact:</strong> ${appointment.patient_contact}</p>`;
            }
            
            // Add notification status
            if (appointment.notification_sent) {
                confirmationHtml += `<p style="color: #4CAF50; font-weight: bold;">✅ Push notification sent successfully!</p>`;
                if (appointment.notification_message) {
                    confirmationHtml += `<p><strong>Notification:</strong> ${appointment.notification_message}</p>`;
                }
            } else {
                confirmationHtml += `<p style="color: #f44336; font-weight: bold;">❌ Push notification failed to send</p>`;
                if (appointment.notification_error) {
                    confirmationHtml += `<p><strong>Error:</strong> ${appointment.notification_error}</p>`;
                }
            }
            
            confirmationHtml += `</div>`;
            
            addMessage(confirmationHtml, "bot");
            
        } catch (e) {
            console.error("Error parsing appointment confirmation:", e);
            addMessage("Appointment confirmed! You will receive a notification shortly.", "bot");
        }
        chatBox.scrollTop = chatBox.scrollHeight;
    }

    function displayEmergencyResponse(emergencyData) {
        console.log("🚨 Displaying emergency response:", emergencyData);
        
        let emergencyHtml = `<div style="background-color: #ffebee; border: 3px solid #f44336; border-radius: 15px; padding: 20px; margin: 15px 0; text-align: center;">
            <h2 style="color: #d32f2f; margin-top: 0; font-size: 24px;">🚨 CRITICAL EMERGENCY DETECTED 🚨</h2>
            <p style="font-size: 18px; color: #d32f2f; font-weight: bold;">Emergency Type: ${emergencyData.emergency_type || 'Medical Emergency'}</p>
            <p style="font-size: 16px; color: #333;">Patient: ${emergencyData.patient_name || 'Unknown'}</p>
            <p style="font-size: 16px; color: #333;">Location: ${emergencyData.patient_location || 'Unknown'}</p>
            <p style="font-size: 16px; color: #28a745; font-weight: bold;">✅ Ambulance Called Successfully</p>
            <p style="font-size: 18px; color: #d32f2f; font-weight: bold;">Emergency Level: CRITICAL</p>
        </div>`;
        
        addMessage(emergencyHtml, "bot");
    }

    function displayEmergencyNotification(notificationData) {
        console.log("🚨 Displaying emergency notification:", notificationData);
        
        let notificationHtml = `<div style="background-color: #fff3e0; border: 3px solid #ff9800; border-radius: 15px; padding: 20px; margin: 15px 0; text-align: center;">
            <h3 style="color: #e65100; margin-top: 0; font-size: 20px;">🚨 Emergency Response Activated</h3>
            <p style="font-size: 16px; color: #333; margin-bottom: 15px;">${notificationData.message || 'Emergency response activated'}</p>
            
            <div style="background-color: #e8f5e8; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h4 style="color: #2e7d32; margin-top: 0;">😌 Stay Calm</h4>
                <p style="color: #333;">Help is on the way. Stay calm and follow medical guidance.</p>
            </div>
            
            <div style="background-color: #fff3cd; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h4 style="color: #856404; margin-top: 0;">⚡ Immediate Actions</h4>
                <ul style="color: #333; margin: 0; padding-left: 20px; text-align: left;">
                    ${notificationData.immediate_actions ? notificationData.immediate_actions.map(action => `<li>${action}</li>`).join('') : '<li>Follow medical guidance</li>'}
                </ul>
            </div>
        </div>`;
        
        addMessage(notificationHtml, "bot");
        
        // Show AI Virtual Doctor ready message
        if (notificationData.ai_virtual_doctor_activated) {
            displayAIVirtualDoctorReady({
                doctor_name: "Sarah Chen",
                emergency_type: notificationData.emergency_type || "Medical Emergency"
            });
        }
    }
        

    function displayAIVirtualDoctorReady(doctorData) {
        addMessage("<pre>AI Virtual Doctor Ready: " + JSON.stringify(doctorData, null, 2) + "</pre>", "bot");
        console.log("🤖 Displaying AI Virtual Doctor ready:", doctorData);
        
        let doctorHtml = `<div style="background-color: #e3f2fd; border: 3px solid #2196f3; border-radius: 15px; padding: 20px; margin: 15px 0; text-align: center;">
            <h3 style="color: #1976d2; margin-top: 0; font-size: 22px;">👨‍⚕️ AI Virtual Doctor Ready</h3>
            <p style="font-size: 16px; color: #333; margin-bottom: 20px;">Dr. ${doctorData.doctor_name || 'Sarah Chen'} is ready to speak with you</p>
            
            <div id="ai-doctor-avatar" style="cursor: pointer; margin: 20px 0; transition: transform 0.3s ease;">
                <img src="/static/doctor_avatar.png" alt="AI Doctor" style="width: 150px; height: 150px; border-radius: 50%; border: 4px solid #2196f3; box-shadow: 0 8px 16px rgba(33, 150, 243, 0.3);">
                <p style="font-size: 14px; color: #666; margin-top: 10px;">Click the doctor to start consultation</p>
            </div>
            
            <p style="font-size: 14px; color: #666; margin-top: 15px;">Click the doctor's image above to begin your consultation</p>
        </div>`;
        
        addMessage(doctorHtml, "bot");
        
        // Add event listener for the doctor avatar
        setTimeout(() => {
            const doctorAvatar = document.getElementById("ai-doctor-avatar");
            if (doctorAvatar) {
                doctorAvatar.addEventListener("click", () => {
                    startAIConsultation(doctorData);
                });
            }
        }, 100);
    }

    function startAIConsultation(doctorData) {
        console.log("👨‍⚕️ Starting AI Doctor Consultation with:", doctorData);
        
        // Show consultation UI with animated doctor image
        let consultationHtml = `
            <div style="background-color: #e8f5e8; border: 3px solid #4caf50; border-radius: 15px; padding: 20px; margin: 15px 0; text-align: center;">
                <h3 style="color: #2e7d32; margin-top: 0; font-size: 20px;">👨‍⚕️ AI Doctor Consultation Started</h3>
                
                <div id="speaking-doctor" style="margin: 20px 0;">
                    <img src="/static/doctor_avatar.png" alt="AI Doctor Speaking" style="width: 150px; height: 150px; border-radius: 50%; border: 4px solid #4caf50; box-shadow: 0 8px 16px rgba(76, 175, 80, 0.4); animation: pulse 2s infinite;">
                    <div style="margin-top: 10px;">
                        <span style="color: #4caf50; font-weight: bold;">●</span>
                        <span style="color: #4caf50; font-weight: bold; animation: blink 1s infinite;">●</span>
                        <span style="color: #4caf50; font-weight: bold; animation: blink 1s infinite 0.3s;">●</span>
                    </div>
                </div>
                
                <p style="font-size: 16px; color: #333; margin-bottom: 15px;">Dr. ${doctorData.doctor_name} is generating audio guidance...</p>
                <p style="font-size: 14px; color: #666; margin-bottom: 15px;">Please wait while the AI doctor prepares your consultation</p>
                
                <div id="audio-controls" style="display: none;">
                    <audio id="ai-doctor-audio" controls style="margin: 10px 0;">
                        Your browser does not support the audio element.
                    </audio>
                    <p style="font-size: 12px; color: #666;">Click play to hear the AI doctor's guidance</p>
                </div>
                
                <button id="stop-consultation" style="background-color: #f44336; color: white; border: none; border-radius: 20px; padding: 10px 20px; font-size: 16px; cursor: pointer; margin: 10px;">
                    🛑 End Consultation
                </button>
            </div>
            
            <style>
                @keyframes pulse {
                    0% { transform: scale(1); }
                    50% { transform: scale(1.05); }
                    100% { transform: scale(1); }
                }
                @keyframes blink {
                    0%, 50% { opacity: 1; }
                    51%, 100% { opacity: 0.3; }
                }
            </style>
        `;
        
        addMessage(consultationHtml, "bot");
        
        // Trigger TTS to generate and play audio (same as test file functionality)
        fetch('/start_ai_doctor_call', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                type: 'consultation',
                doctor_name: doctorData.doctor_name
            }),
        })
        .then(response => response.json())
        .then(data => {
            console.log("🎵 Audio response:", data);
            
            if (data.status === "started" || data.status === "audio_generated") {
                // Update the UI to show audio controls
                const audioControls = document.getElementById("audio-controls");
                const audioElement = document.getElementById("ai-doctor-audio");
                const statusText = document.querySelector("#speaking-doctor").nextElementSibling;
                
                if (audioControls && audioElement && statusText) {
                    audioControls.style.display = "block";
                    
                    // Use the audio file path (same as test file)
                    const audioPath = `/audio/${data.audio_file}`;
                    audioElement.src = audioPath;
                    console.log("🎵 Setting audio source:", audioPath);
                    
                    statusText.textContent = `Dr. ${doctorData.doctor_name} is now speaking with you`;
                    
                    // Auto-play if audio was started by the server (same as test file)
                    if (data.status === "started") {
                        console.log("🎵 Attempting auto-play...");
                        audioElement.play().then(() => {
                            console.log("✅ Audio auto-play successful");
                        }).catch(e => {
                            console.log("⚠️ Auto-play blocked by browser:", e);
                            // Show manual play instruction
                            statusText.textContent = `Dr. ${doctorData.doctor_name} is ready. Click play to hear the consultation.`;
                        });
                    } else {
                        // Manual play required
                        statusText.textContent = `Dr. ${doctorData.doctor_name} is ready. Click play to hear the consultation.`;
                    }
                    
                    // Add audio event listeners for better UX
                    audioElement.addEventListener('play', () => {
                        console.log("🎵 Audio started playing");
                        statusText.textContent = `Dr. ${doctorData.doctor_name} is speaking...`;
                    });
                    
                    audioElement.addEventListener('ended', () => {
                        console.log("🎵 Audio finished playing");
                        statusText.textContent = `Dr. ${doctorData.doctor_name} consultation completed.`;
                    });
                    
                    audioElement.addEventListener('error', (e) => {
                        console.error("❌ Audio error:", e);
                        statusText.textContent = `❌ Audio playback error. Please try again.`;
                    });
                }
            } else {
                console.error("❌ Audio generation failed:", data.message);
                const statusText = document.querySelector("#speaking-doctor").nextElementSibling;
                if (statusText) {
                    statusText.textContent = `❌ Failed to generate audio: ${data.message}`;
                }
            }
        })
        .catch(error => {
            console.error("❌ Error starting consultation:", error);
            const statusText = document.querySelector("#speaking-doctor").nextElementSibling;
            if (statusText) {
                statusText.textContent = "❌ Error starting consultation. Please try again.";
            }
        });
        
        setTimeout(() => {
            const stopButton = document.getElementById("stop-consultation");
            if (stopButton) {
                stopButton.addEventListener("click", () => {
                    endAICall();
                });
            }
        }, 100);
    }

    function endAICall() {
        let endCallHtml = `<div style="background-color: #fff3cd; border: 2px solid #ffc107; border-radius: 10px; padding: 15px; margin: 10px 0; text-align: center;">
            <h3 style="color: #856404; margin-top: 0;">📞 Call Ended</h3>
            <p style="color: #333;">The AI doctor consultation has ended. Emergency services are still on their way.</p>
        </div>`;
        
        addMessage(endCallHtml, "bot");
    }

    function displayAIVirtualDoctor(aiDoctorData) {
        console.log("🤖 Displaying AI Virtual Doctor:", aiDoctorData);
        // Only show doctor profile, video call setup, and status. Do NOT show any script text.
        if (aiDoctorData.doctor_profile) {
            const profile = aiDoctorData.doctor_profile;
            let profileHtml = `<div style="background-color: #e3f2fd; border: 2px solid #2196f3; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #1976d2; margin-top: 0;">🤖 AI Virtual Doctor Profile</h3>
                <div style="background-color: #fff; border-radius: 8px; padding: 12px; margin: 8px 0;">
                    <p><strong>Doctor Name:</strong> ${profile.doctor_name || 'Dr. AI Assistant'}</p>
                    <p><strong>Credentials:</strong> ${profile.credentials || 'MD, Emergency Medicine'}</p>
                    <p><strong>Specialization:</strong> ${profile.specialization || 'Emergency Medicine'}</p>
                    <p><strong>Experience:</strong> ${profile.experience_years || '10+ years'}</p>
                    <p><strong>Speaking Style:</strong> ${profile.speaking_style || 'Professional and reassuring'}</p>
                </div>
                <p style="font-size: 12px; color: #666; margin-top: 8px;">
                    <em>This AI doctor will conduct your emergency consultation using advanced medical knowledge.</em>
                </p>
            </div>`;
            addMessage(profileHtml, "bot");
        }
        // Show consultation ready status
        if (aiDoctorData.video_call_setup) {
            let consultationHtml = `<div style="background-color: #e8f5e8; border: 2px solid #4caf50; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #2e7d32; margin-top: 0;">👨‍⚕️ AI Doctor Consultation Ready</h3>
                <p><strong>Status:</strong> ✅ AI Doctor ready for consultation</p>
                <p><strong>Audio:</strong> Text-to-Speech enabled</p>
                <div style="margin: 10px 0;">
                    <img src="/static/doctor_avatar.png" alt="AI Doctor" style="width: 120px; height: 120px; border-radius: 50%; margin: 10px 0;">
                </div>
                <p style="font-size: 12px; color: #666; margin-top: 8px;">
                    <em>Click the doctor's image above to start your consultation with audio guidance.</em>
                </p>
            </div>`;
            addMessage(consultationHtml, "bot");
        }
        // Do NOT show any script text here!
        // Only show real-time response templates if you want (optional, not the script)
        if (aiDoctorData.real_time_responses) {
            const responses = aiDoctorData.real_time_responses;
            let responsesHtml = `<div style="background-color: #f3e5f5; border: 2px solid #9c27b0; border-radius: 10px; padding: 15px; margin: 10px 0;">
                <h3 style="color: #7b1fa2; margin-top: 0;">💬 AI Doctor Response Templates</h3>
                <p style="font-size: 12px; color: #666; margin-bottom: 10px;">
                    <em>The AI doctor can respond to various patient interactions during the consultation:</em>
                </p>`;
            Object.entries(responses).forEach(([key, response]) => {
                const title = key.replace(/_/g, ' ').replace(/\b\w/g, l => l.toUpperCase());
                responsesHtml += `<div style="background-color: #fff; border-radius: 8px; padding: 10px; margin: 5px 0;">
                    <strong style="color: #7b1fa2;">${title}:</strong>
                    <p style="font-style: italic; margin: 5px 0; font-size: 14px;">"${response}"</p>
                </div>`;
            });
            responsesHtml += `</div>`;
            addMessage(responsesHtml, "bot");
        }
    }
    
    function displayAIDoctorSpeech(speechData) {
        addMessage("<pre>AI Doctor Speech: " + JSON.stringify(speechData, null, 2) + "</pre>", "bot");
        console.log("🗣️ Displaying AI Doctor Speech:", speechData);
        
        let speechHtml = `<div style="background-color: #fff3cd; border: 2px solid #ffc107; border-radius: 10px; padding: 15px; margin: 10px 0;">
            <h3 style="color: #856404; margin-top: 0;">🗣️ AI Doctor Speaking</h3>
            <p><strong>Doctor:</strong> ${speechData.doctor_name || 'Dr. AI Assistant'}</p>
            <p><strong>Status:</strong> ${speechData.speech_generated ? '✅ Speaking' : '❌ Speech failed'}</p>
            <p><strong>Text:</strong> ${speechData.text_spoken ? speechData.text_spoken.substring(0, 100) + '...' : 'No text available'}</p>
            <p><strong>Duration:</strong> ${speechData.speech_duration ? Math.round(speechData.speech_duration) + ' seconds' : 'Unknown'}</p>
            <p><strong>Voice Config:</strong> ${speechData.voice_config ? `${speechData.voice_config.gender}, Rate: ${speechData.voice_config.rate}` : 'Default'}</p>
            <p style="font-size: 12px; color: #666; margin-top: 8px;">
                <em>AI Doctor is speaking the medical guidance. Please listen carefully.</em>
            </p>
        </div>`;
        
        addMessage(speechHtml, "bot");
    }
}); // Close DOMContentLoaded event listener